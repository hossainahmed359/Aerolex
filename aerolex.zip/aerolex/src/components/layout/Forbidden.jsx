export const Forbidden = () => {
  return <p>403 Forbidden</p>
}