import Head from 'next/head';

const Home = () => {
  return (
    <div>
      <Head>
        <title>Aerolex</title>
        <meta name="Aerolex" content="Aerolex" />
        <link rel="icon" href="/favicon.ico" />
      </Head>

      <main>
        <div className="home">
          <h2>Aerolex</h2>
        </div>
      </main>

      <footer></footer>
    </div>
  );
};

export default Home;
