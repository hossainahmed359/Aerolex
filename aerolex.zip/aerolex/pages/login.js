const Login = () => {
  return (
    <div>
      <p>Please login</p>
    </div>
  );
};

export default Login;
